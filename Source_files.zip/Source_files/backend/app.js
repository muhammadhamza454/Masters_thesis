const express = require("express");
const cors = require('cors');
// const bodyParser = require('body-parser');



// express app
const app = express();
// app.use(bodyParser.urlencoded({extended: true}));
// configure the app to use bodyParser()
app.use(express.urlencoded());
app.use(express.json())



// listen for requests
app.listen(5200);

// register view engine
app.set("view engine", "ejs");
// app.set('views', 'myviews');


app.use(cors());
app.options('*', cors()); // request accept from all server

var pg = require('pg');
var connectionString = "postgres://postgres:Hafizhabib.123@localhost:5433/ethiopia";
var pgClient = new pg.Client(connectionString);
pgClient.connect().then(() => console.log("Connected Successfully"));





app.get("/", (req, res) => {
  const blogs = [
    {
      title: "Hamza finds eggs",
      snippet: "Lorem ipsum dolor sit amet consectetur",
    },
    {
      title: "Mario finds stars",
      snippet: "Lorem ipsum dolor sit amet consectetur",
    },
    {
      title: "How to defeat bowser",
      snippet: "Lorem ipsum dolor sit amet consectetur",
    },
  ];
  res.json({ blogs });
});



// finding the line

app.get("/roads/:a/:b", async (req, res) => {
  const dbroad = await pgClient.query(`SELECT osm_id,name,ST_asgeojson(geom),ST_Distance(ST_Buffer(r.geom,0.00000000000001),ST_SetSRID(ST_MakePoint(${req.params.b}, ${req.params.a}),4326)) FROM export2 r ORDER BY ST_distance ASC  LIMIT 1;`);
  res.json({
    dbroad
  })
});


// Updating after getting that line


app.get("/updategid/:c/:e", async (req, res) => {
  await pgClient.query(`UPDATE export2 SET street_cond ='${req.params.e}' WHERE osm_id = '${req.params.c}'`);
});

// Updating Date


app.get("/updatedate/:d", async (req, res) => {
  await pgClient.query(`UPDATE updatedate
  SET updatedate1 = '${req.params.d}'
  WHERE updatedate1 IS NOT NULL;`);
});


// Testing CSV file data insert

// app.get("/csv/:d", async (req, res) => {
//   try {
//     const message = await pgClient.query(`insert into img (lat, lon, username) values('32', '54', '${req.params.d}');`);
//     res.json({
//       name: req.params.d,
//       message: message
//     })
//   } catch (error) {
//     console.log(req.params.d, error)
//     res.json({
//       message: error
//     })
//   }
// });


// adding the image link in the point data

app.post("/saveimage", async (req, res) => {
  console.log(req.body.ImageUrl)
  await pgClient.query(`INSERT INTO LATLON (lat, lon,image,epoles,pothole) VALUES ('${req.body.lat}', '${req.body.lon}' , '${req.body.ImageUrl}', '${req.body.epole}', '${req.body.pothole}')`);
  res.json(req.body)
});

// Adding the village data
app.post("/villagedata", async (req, res) => {
  await pgClient.query(`INSERT INTO village (lat, lon, village_name, vehicles, population, men, women, deaths, gas, fields, built_up, budget,
  accidents,bus,motorbike,car,electric_car,rikshaw) 
  VALUES ('${req.body.lat}', '${req.body.lon}' , '${req.body.name}', '${req.body.vehicle}', '${req.body.pop}', '${req.body.men}', 
  '${req.body.women}', '${req.body.death}', '${req.body.gas}', '${req.body.pastures}', '${req.body.builtup}', '${req.body.budget}', 
  '${req.body.accident}','${req.body.bus}','${req.body.motorbike}','${req.body.car}','${req.body.ecar}','${req.body.rikshaw}')`);
  res.json(req.body)
});



// app.get("/hamza/:a/:b", async (req, res) => {

  // await pgClient.query(`INSERT INTO LATLON (lat, lon) VALUES(${req.params.a},${req.params.b})`);



  // var dbresponse = null;
  // Check validity of parameters (coordinates of point)
  // Get road from Postgres using the the coordinates
  // SELECT name,ST_Distance(tn.geom,ST_SetSRID(ST_MakePoint(params.lon, params.lat),4326)) FROM table_name tn ORDER BY 2 ASC LIMIT 1;
  // console.log(err,res)

  //   pgClient.query("SELECT ST_AsGeoJSON(geom) from gis_osm_railways_free_1",(err,res)=>{
  //     console.log(err,res)
  //     dbresponse=res
  //     pgClient.end()
  // });



  // const dbroads = await pgClient.query("SELECT street_cond,ST_AsGeoJSON(geom) from export2");




  // const dbresponse = await pgClient.query("SELECT lat, lon, image from LATLON");
  // res.json({
  //   dbresponse, dbroads
    // response: {
    //   type: "FeatureCollection",
    //   features: [
    //     {
    //       type: "Feature",
    //       properties: {
    //         color: "red",
    //         lat: req.params.a,
    //         lon: req.params.b,
    //         name:"Ring Road (res.name)"
    //       },
    //       geometry: {
    //         type: "LineString",
    //         coordinates: [
    //           [74.27987337112427, 31.563708933908995],
    //           [74.28266286849976, 31.56895606333033],
    //           [74.2847228050232, 31.572612424950545],
    //           [74.28673982620239, 31.576561134446788],
    //           [74.28952932357788, 31.58140538752576],
    //           [74.29028034210205, 31.582666680034297],
    //         ],
    //       },
    //     },
    //   ],
    // },
//   });
// });


// app.get((req, res) => {
//   const creattable = await pgClient.query("INSERT TABLE LATLON (ID serial, lat text, lon text) VALUES(1,)");
// });

app.get("/show", async (req, res) => {
  const dbresponse = await pgClient.query("SELECT lat, lon, image, epoles, pothole from LATLON");
  const dbresponse2 = await pgClient.query("SELECT lat, lon, village_name, vehicles, population, men, women, deaths, gas, fields, built_up, budget,accidents, bus, motorbike, car, electric_car, rikshaw from village");
  const dbroads = await pgClient.query("SELECT street_cond,ST_AsGeoJSON(geom) from export2");
  const getdate= await pgClient.query("SELECT updatedate1 from updatedate");
  res.json({
    dbroads,dbresponse,dbresponse2,getdate
  });
  
});


// 404 page
app.use((req, res) => {
  res.status(404).render("404", { title: "404" });
});
