
var GPSImagelatitude;
var GPSImageLongitude;
var clickedlat,clickedlon;
// Only for testing of group layer

var streets = L.layerGroup();
var Point = L.layerGroup();

// var Population2=L.layerGroup();

var Population=L.layerGroup();
var Vehicles=L.layerGroup();
var Deaths=L.layerGroup();
var Gas=L.layerGroup();
var Landcover=L.layerGroup();
var Budget=L.layerGroup();
var Accidents=L.layerGroup();

// Available files
var availpdf=L.layerGroup();
var availimg=L.layerGroup();




// Map

var mymap = L.map("mapid").setView(
  [
    6.811804, -5.270520
  ],
  13
);
 var base1=L.tileLayer("http://{s}.google.com/vt/lyrs=m&x={x}&y={y}&z={z}", {
  maxZoom: 20,
  subdomains: ["mt0", "mt1", "mt2", "mt3"],
});

var base2= L.tileLayer('https://tiles.stadiamaps.com/tiles/alidade_smooth_dark/{z}/{x}/{y}{r}.png', {
	maxZoom: 20,
	attribution: '&copy; <a href="https://stadiamaps.com/">Stadia Maps</a>, &copy; <a href="https://openmaptiles.org/">OpenMapTiles</a> &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors'
}).addTo(mymap);

var base3=L.tileLayer('https://tiles.stadiamaps.com/tiles/alidade_smooth/{z}/{x}/{y}{r}.png', {
	maxZoom: 20,
	attribution: '&copy; <a href="https://stadiamaps.com/">Stadia Maps</a>, &copy; <a href="https://openmaptiles.org/">OpenMapTiles</a> &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors'
});





// ICONS*****
var streetIcon = L.icon({
  iconUrl: 'imgpin.png',
});





// Heatpoint demo

// var heat = L.heatLayer([[7.945594,39.138744],[9.313608, 42.116089]], 
//   {
//   radius: 50,
//   max: 1.0,
             
//   gradient: {
//       0.2: 'blue',
//       0.5:'green',
//       0.6: 'yellow',
//       1.0: 'red'
//   },
//   minOpacity: 0.7
// });

visualize();



// Layer contol

var basemap={'Street View':base1,'Grey Mode':base3,'Dark Mode': base2};
var overlayMaps={'PDF':availpdf,'Images':availimg,'Streets View':Point,'Roads':streets,'Population': Population,'Vehicles':Vehicles,'Deaths':Deaths,'Gas':Gas,'Landcover':Landcover,'Budget':Budget,'Accidents':Accidents};
L.control.layers(basemap,overlayMaps).addTo(mymap);





//scale******
L.control.scale().addTo(mymap);


// Legends

var legend = L.control({ position: "bottomleft" });

legend.onAdd = function(mymap) {
  var div = L.DomUtil.create("div", "legend");
  div.innerHTML += "<p><b>Legend</b></p>";
  div.innerHTML += "<p><b>Road Level</b></p>";
  div.innerHTML += '<i style="background: Green"></i><span>Good</span><br>';
  div.innerHTML += '<i style="background: Yellow"></i><span>Moderate</span><br>';
  div.innerHTML += '<i style="background: Red"></i><span>Bad</span><br>';
  div.innerHTML += '<i class="icon" style="background-image: url(pins/imgpin.png);background-repeat: no-repeat;"></i><span>Road Image</span><br>';
  div.innerHTML += "<br>";
  div.innerHTML += "<p><b>Village Level</b></p>";
  div.innerHTML += '<i class="icon" style="background-image: url(pins/Vehicles.png);background-repeat: no-repeat;"></i><span>Vehicles</span><br>';
  div.innerHTML += '<i class="icon" style="background-image: url(pins/deaths.png);background-repeat: no-repeat;"></i><span>Deaths</span><br>';
  div.innerHTML += '<i class="icon" style="background-image: url(pins/CO2.png);background-repeat: no-repeat;"></i><span>Gass (CO2)</span><br>';
  div.innerHTML += '<i class="icon" style="background-image: url(pins/Builtup.png);background-repeat: no-repeat;"></i><span>Land Cover</span><br>';
  div.innerHTML += '<i class="icon" style="background-image: url(pins/Budget.png);background-repeat: no-repeat;"></i><span>Budget</span><br>';
  div.innerHTML += '<i class="icon" style="background-image: url(pins/accidents.png);background-repeat: no-repeat;"></i><span>Accidents</span><br>';
  div.innerHTML += '<i><span class="dot"></span></i><span>Population</span>';
  return div;
};
legend.addTo(mymap);



  // Date for updates
  var d = new Date();
  var Date2;


// CLick on map and getting lat long

mymap.on('click', 
					function(e){
						var coord = e.latlng.toString().split(',');
						clickedlat = coord[0].split('(');
						clickedlon = coord[1].split(')');
						console.log("You clicked the map at latitude: " + clickedlat[1] + " and longitude:" + clickedlon[0]);
					});





// Visualize when page opens

async function visualize(){

  const road = await axios.get(`http://localhost:5200/show/`);



var legend = L.control({ position: "bottomright" });

road.data.getdate.rows.forEach(row => {

legend.onAdd = function(mymap) {
  var div = L.DomUtil.create("div", "legend2");
  div.innerHTML += "<p><b> Last Update:  "+row.updatedate1+"</b></p>";
  return div;
};
legend.addTo(mymap);

});

  road.data.dbroads.rows.forEach(row => {

    var s;

    var type;
    if (row.street_cond == 'Good') {
      type = "Green";
    }
    else if (row.street_cond == 'Moderate') {
      type = "Yellow";
    }
    else if (row.street_cond == 'Bad') {
      type = "Red";
    }
    else
      type = "white";
    

       s = L.geoJSON(JSON.parse(row.st_asgeojson), {

        style: {
          "color":type,
          "weight": 2,
          "opacity": 1
        }
      });

    streets.addLayer(s);
   
  });

// Points

road.data.dbresponse.rows.forEach(row => {
  var p;
  var legend
  p=L.marker([Number(row.lat), Number(row.lon)],{icon: streetIcon}).bindPopup(`<h10><b>Street View</b></h10>
 <img src="${row.image}" height="100%" width="100%" class="markerPopupImage"resizable=1/>
 <br>
 <h10><b>Street Information</b></h10>
 <p>Potholes: ${row.pothole}, Electric poles:${row.epoles}</p>`).on('mouseover',function(e){

  legend= L.control({ position: "bottomright" });

  legend.onAdd = function(mymap) {
    var div = L.DomUtil.create("div", "legend");
    div.innerHTML += "<p><b>Street View</b></p>";
    div.innerHTML += "<p><b>Potholes: "+row.pothole+"</b></p>";
    div.innerHTML += "<p><b>Electric Poles: "+row.epoles+"</b></p>";
    return div;
  };
  legend.addTo(mymap);

 }).on('mouseout',function(e){

  legend.remove();

 });
// Adding all points in one layer group
 Point.addLayer(p);

});


//Population points

road.data.dbresponse2.rows.forEach(row => {
  var h, popu2;
  h=L.marker([Number(row.lat), Number(row.lon)], {
    icon: L.divIcon({
        className: 'my-custom-icon',
        html: row.population,
        iconAnchor:   [25, 25],
        iconSize: [50,50],
    
    })
  }).bindPopup(`<h10><b>Population</b></h10>
  <p>Vaillage: ${row.village_name} <br> Men: ${row.men} <br> Women:${row.women}</p>`).on('mouseover',function(e){

    legend= L.control({ position: "bottomright" });
  
    legend.onAdd = function(mymap) {
      var div = L.DomUtil.create("div", "legend");
      div.innerHTML += "<p><b>Population</b></p>";
      div.innerHTML += "<p><b>Village: "+row.village_name+"</b></p>";
      div.innerHTML += "<p><b>Total Population: "+row.population+"</b></p>";
      div.innerHTML += "<p><b>Men: "+row.men+"</b></p>";
      div.innerHTML += "<p><b>Men: "+row.women+"</b></p>";
      return div;
    };
    legend.addTo(mymap);
  
   }).on('mouseout',function(e){
  
    legend.remove();
  
   });
  Population.addLayer(h);


  //  In case heat map usage


// popu2=L.heatLayer([[Number(row.lat), Number(row.lon)]], 
//   {
//   radius: row.population/10,
//   max: 1.0,
             
//   gradient: {
//       0.2: 'blue',
//       0.5:'green',
//       0.6: 'yellow',
//       1.0: 'red'
//   },
//   minOpacity: 0.7
// }).bindPopup(`
// <p>Vaillage: ${row.village_name} <br> Men: ${row.men} <br> Women:${row.women}</p>`).on('mouseover',function(e){

//   legend= L.control({ position: "bottomright" });

//   legend.onAdd = function(mymap) {
//     var div = L.DomUtil.create("div", "legend");
//     div.innerHTML += "<p><b>Population</b></p>";
//     div.innerHTML += "<p><b>Village: "+row.village_name+"</b></p>";
//     div.innerHTML += "<p><b>Total Population: "+row.population+"</b></p>";
//     div.innerHTML += "<p><b>Men: "+row.men+"</b></p>";
//     div.innerHTML += "<p><b>Men: "+row.women+"</b></p>";
//     return div;
//   };
//   legend.addTo(mymap);

//  }).on('mouseout',function(e){

//   legend.remove();

//  });

// Population2.addLayer(popu2);



// var text = L.tooltip({
//   permanent: true,
//   direction: 'Top',
//   className: 'text',
//   opacity: 0.8,
// })
// .setContent("Population:"+row.population)
// .setLatLng([Number(row.lat), Number(row.lon)]);
// text.addTo(Population2);

//   h=L.circle([Number(row.lat), Number(row.lon)], {
//     color: 'f06',
//     fillColor: '#f03',
//     fillOpacity: 0.5,
//     radius: 500
//   }).bindPopup(`
//   <p>Vaillage: ${row.village_name} <br> Men: ${row.men} <br> Women:${row.women}</p>`)
//   Population.addLayer(h);
  
//   // Text


});



//Vehicles points

road.data.dbresponse2.rows.forEach(row => {
  var veh;
  veh=L.marker([Number(row.lat), Number(row.lon)],{icon: L.icon({
    iconUrl: 'pins/Vehicles.png',
    iconAnchor:   [25, 25],
    iconSize: [50,50],
  })
}).bindPopup(`<h10><b>VEHICLES</b></h10><p>Bus: ${row.bus} <br> Motorbikes: ${row.motorbike} <br> Cars:${row.car}<br>
Electric cars: ${row.electric_car} <br>Rikshaw: ${row.rikshaw} <br></p>`).on('mouseover',function(e){

  legend= L.control({ position: "bottomright" });

  legend.onAdd = function(mymap) {
    var div = L.DomUtil.create("div", "legend");
    div.innerHTML += "<p><b>Vehicles</b></p>";
    div.innerHTML += "<p><b>Total: "+row.vehicles+"</b></p>";
    div.innerHTML += "<p><b>Buses: "+row.bus+"</b></p>";
    div.innerHTML += "<p><b>Motorbikes: "+row.motorbike+"</b></p>";
    div.innerHTML += "<p><b>Cars: "+row.car+"</b></p>";
    div.innerHTML += "<p><b>Rikshaws: "+row.rikshaw+"</b></p>";
    div.innerHTML += "<p><b>Electric cars: "+row.electric_car+"</b></p>";
    return div;
  };
  legend.addTo(mymap);

 }).on('mouseout',function(e){

  legend.remove();

 }).openPopup();
  Vehicles.addLayer(veh);
  

});








//Deaths points

road.data.dbresponse2.rows.forEach(row => {
  var det;
  det=L.marker([Number(row.lat), Number(row.lon)],{icon: L.icon({
    iconUrl: 'pins/deaths.png',
    iconAnchor:   [25, 25],
    iconSize: [50,50],
  })
}).bindPopup(`<h10><b>Deaths Happened</b></h10><br>`+ row.deaths).on('mouseover',function(e){

  legend= L.control({ position: "bottomright" });

  legend.onAdd = function(mymap) {
    var div = L.DomUtil.create("div", "legend");
    div.innerHTML += "<p><b>Deaths</b></p>";
    div.innerHTML += "<p><b>Deaths per 1000 people: "+row.deaths+"</b></p>";
    return div;
  };
  legend.addTo(mymap);

 }).on('mouseout',function(e){

  legend.remove();

 });
  Deaths.addLayer(det);
  
});

//Gas points

road.data.dbresponse2.rows.forEach(row => {
  var g;
  g=L.marker([Number(row.lat), Number(row.lon)],{icon: L.icon({
    iconUrl: 'pins/CO2.png',
    iconAnchor:   [25, 25],
    iconSize: [50,50],
  })}).bindPopup(`<h10><b>Gas Emission Value</b></h10><br>`+row.gas).on('mouseover',function(e){

    legend= L.control({ position: "bottomright" });
  
    legend.onAdd = function(mymap) {
      var div = L.DomUtil.create("div", "legend");
      div.innerHTML += "<p><b>Gas Emission</b></p>";
      div.innerHTML += "<p><b>Gas Emission Value (Metric tons per capita): "+row.gas+"</b></p>";
      return div;
    };
    legend.addTo(mymap);
  
   }).on('mouseout',function(e){
  
    legend.remove();
  
   });
  Gas.addLayer(g);
});


//Landuse points

road.data.dbresponse2.rows.forEach(row => {
  var land;
  land=L.marker([Number(row.lat), Number(row.lon)],{icon: L.icon({
    iconUrl: 'pins/Builtup.png',
    iconAnchor:   [25, 25],
    iconSize: [50,50],
  })}).bindPopup(`<h10><b>Landuse Informataion</b></h10>
  <p>Built_up Area: ${row.built_up} <br> Pastures/ fields:${row.fields}</p>`).on('mouseover',function(e){

    legend= L.control({ position: "bottomright" });
  
    legend.onAdd = function(mymap) {
      var div = L.DomUtil.create("div", "legend");
      div.innerHTML += "<p><b>Landuse</b></p>";
      div.innerHTML += "<p><b>Built_up Area: "+row.built_up+"</b></p>";
      div.innerHTML += "<p><b>Fields: "+row.fields+"</b></p>";
      return div;
    };
    legend.addTo(mymap);
  
   }).on('mouseout',function(e){
  
    legend.remove();
  
   });
  Landcover.addLayer(land);
  
  // Text

//   var text = L.tooltip({
//     permanent: true,
//     direction: 'top',
//     className: 'text',
//     opacity: 0.8,
// })
// .setContent("Builtup:"+row.built_up+"%" + " Fields:"+row.fields+"%")
// .setLatLng([Number(row.lat), Number(row.lon)]);
// text.addTo(Landcover);
});

//Budget points

road.data.dbresponse2.rows.forEach(row => {
  var budget1;
  budget1=L.marker([Number(row.lat), Number(row.lon)],{icon: L.icon({
    iconUrl: 'pins/Budget.png',
    iconAnchor:   [25, 25],
    iconSize: [50,50],
  })}).bindPopup(`<h10><b>Budget Available</b></h10><br>`+row.budget).on('mouseover',function(e){

    legend= L.control({ position: "bottomright" });
  
    legend.onAdd = function(mymap) {
      var div = L.DomUtil.create("div", "legend");
      div.innerHTML += "<p><b>Budget</b></p>";
      div.innerHTML += "<p><b>Budget Available: "+row.budget+"</b></p>";
      return div;
    };
    legend.addTo(mymap);
  
   }).on('mouseout',function(e){
  
    legend.remove();
  
   });;
  Budget.addLayer(budget1);
  
//   // Text

//   var text = L.tooltip({
//     permanent: true,
//     direction: 'top',
//     className: 'text',
//     opacity: 0.8,
// })
// .setContent(row.budget)
// .setLatLng([Number(row.lat), Number(row.lon)]);
// text.addTo(Budget);
});

//Accidents points

road.data.dbresponse2.rows.forEach(row => {
  var acc;
  acc=L.marker([Number(row.lat), Number(row.lon)],{icon: L.icon({
    iconUrl: 'pins/accidents.png',
    iconAnchor:   [25, 25],
    iconSize: [50,50],
  })}).bindPopup(`<h10><b>Accidents Happened</b></h10><br>`+row.accidents).on('mouseover',function(e){

    legend= L.control({ position: "bottomright" });
  
    legend.onAdd = function(mymap) {
      var div = L.DomUtil.create("div", "legend");
      div.innerHTML += "<p><b>Accidents</b></p>";
      div.innerHTML += "<p><b>Accidents Happened: "+row.accidents+"</b></p>";
      return div;
    };
    legend.addTo(mymap);
  
   }).on('mouseout',function(e){
  
    legend.remove();
  
   });;
  Accidents.addLayer(acc);
  
});

}


// Upload Image Function



function updatefunction() {


  ImgName = document.getElementById('iname').value;
  ImgUser=document.getElementById('iuser').value;
  // ImgLat=document.getElementById('ilat').value;
  // ImgLon=document.getElementById('ilon').value;
  var uploadTask = firebase.storage().ref('Images/' + ImgName + ".png").put(files[0]);
  uploadTask.on('state_changed', function (snapshot) {
  },
    function (error) {
      alert('Error in svaing');
    },
    function () {
      uploadTask.snapshot.ref.getDownloadURL().then(function (url) {
        ImageUrl = url.toString();
        console.log(ImageUrl);
         // Storing in firestore database 
         var db = firebase.firestore();

         const newMessageRef = db.collection("Images").doc();
          newMessageRef.set({
           Name: ImgName,
           Lat:GPSImagelatitude,
           Long:GPSImageLongitude,
           User:ImgUser,
           URL: ImageUrl
       })
        alert('image added successfully');
      })
    }

  );
  



}



// Uploadding PDF on firebase storage
function updatefilefunction() {


  fileName = document.getElementById('rname').value;
  fileUser=document.getElementById('ruser').value;
  var uploadTask = firebase.storage().ref('PDF/' + fileName + ".pdf").put(files[0]);
  uploadTask.on('state_changed', function (snapshot) {
  },
    function (error) {
      alert('Error in svaing');
    },
    function () {
  
  
      uploadTask.snapshot.ref.getDownloadURL().then(function (url) {
        fileUrl = url.toString();
        console.log(fileUrl);
  
        // Storing in firestore database 
        var db = firebase.firestore();

        const newMessageRef = db.collection("PDF").doc();
         newMessageRef.set({
          Name: fileName,
          Lat:clickedlat[1],
          Long:clickedlon[0],
          URL: fileUrl,
          User:fileUser
      })
  
  
  
        // document.getElementById('iframe').src = ImageUrl; // Uploading on iframe the pdf
  
        alert('PDF added successfully');
      })
    }
  
  );


  
  }

  // Get data from firestore database PDF DATA***

function Retrievepdfs(){
 


  var db = firebase.firestore();
  db.collection("PDF")
  .get()
  .then((querySnapshot) => {
      querySnapshot.forEach((doc) => {
      
        let data=doc.data();
          console.log( doc.data().Name);

          if(data.User=="ASTU"){

             //Sending the data in table
          let row  = `<tr>
          <p><a href="${data.URL}" target="_blank" rel="noopener noreferrer" style="font-size: 10px; color:black">${data.Name}<i><img src="pins/pdf.png" width="15px" style="float:right "></i></a></p>
          <hr class="rounded"></tr>`;
        let table = document.getElementById('myTable')
        table.innerHTML += row

          }

          if(data.User=="TUM"){

            //Sending the data in table
         let row  = `<tr>
         <p><a href="${data.URL}" target="_blank" rel="noopener noreferrer" style="font-size: 10px; color:black">${data.Name}<i><img src="pins/pdf.png" width="15px" style="float:right "></i></a></p>
         <hr class="rounded"></tr>`;
       let table = document.getElementById('myTable2')
       table.innerHTML += row

         }

         if(data.User=="INPHB"){

          //Sending the data in table
       let row  = `<tr>
       <p><a href="${data.URL}" target="_blank" rel="noopener noreferrer" style="font-size: 10px; color:black">${data.Name}<i><img src="pins/pdf.png" width="15px" style="float:right "></i></a></p>
       <hr class="rounded"></tr>`;
     let table = document.getElementById('myTable3')
     table.innerHTML += row

       }
         

         
          

      });
  });


}


  // Get data from firestore database Image DATA***

  function Retrieveimages(){
 


    var db = firebase.firestore();
    db.collection("Images")
    .get()
    .then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
        
          let data=doc.data();
            console.log( doc.data().Name);
  
            if(data.User=="ASTU"){
  
               //Sending the data in table
            let row  = `<tr>
            <p class="availdatatext" style="font-size: 10px;">Name: ${data.Name}<i><img src="pins/img.png" width="30px" style="float:right "></i><br> 
            Latitude:${data.Lat} <br> Longitude:${data.Long} <br><a style="color:black;font-size:15px;border-style: solid;border-radius: 5px;
            border-color: rgb(11, 58, 89);" href="${data.URL}" target="_blank" rel="noopener 
            noreferrer">Open</a> </p>
            <hr class="rounded"> </tr>`;
          let table = document.getElementById('myTable4')
          table.innerHTML += row
  
            }
  
            if(data.User=="TUM"){
  
              //Sending the data in table
           let row  = `<tr><span class='icon1'></span>
           <p class="availdatatext" style="font-size: 10px;">Name: ${data.Name}<i><img src="pins/img.png" width="30px" style="float:right "></i> <br>
            Latitude:${data.Lat} <br> Longitude:${data.Long}<br><a style="color:black;font-size:15px;border-style: solid;border-radius: 5px;
            border-color: rgb(11, 58, 89);" href="${data.URL}" target="_blank" 
           rel="noopener noreferrer" style="font-size: 5px;">Open</a></p>
           <hr class="rounded"> </tr>`;
         let table = document.getElementById('myTable5')
         table.innerHTML += row
  
           }
           if(data.User=="INPHB"){
  
            //Sending the data in table
         let row  = `<tr>
         <p class="availdatatext" style="font-size: 10px;">Name: ${data.Name}<i><img src="pins/img.png" width="30px" 
         style="float:right "></i> <br> Latitude:${data.Lat} <br> Longitude:${data.Long}<br><a style="color:black;font-size:15px;border-style: solid;border-radius: 5px;
         border-color: rgb(11, 58, 89);" 
         href="${data.URL}" target="_blank" 
         rel="noopener noreferrer" style="font-size: 5px;">Open</a></p>
         <hr class="rounded"> </tr>`;
       let table = document.getElementById('myTable6')
       table.innerHTML += row

         }
  
           
            
  
        });
    });
  
  
  }




    // Get Image URL From User input Lat and Long***
    // Plus Street Processing

    async function ImageURLExtract(){
 
      var userimagerul;
      var street_id;
      userimgname = document.getElementById('piname').value;
      street_type=document.getElementById('pitype').value;
      street_lat=document.getElementById('pilat').value;
      street_lon=document.getElementById('pilon').value;
      street_pothole=document.getElementById('pipothole').value;
      street_epoles=document.getElementById('pipoles').value;

      const streets = await axios.get(`http://localhost:5200/roads/${street_lat}/${street_lon}`);



    
      var db = firebase.firestore();
      db.collection("Images")
      .get()
      .then((querySnapshot) => {
          querySnapshot.forEach((doc) => {
          
            let data=doc.data();
              
           
              if(data.Name == userimgname)
              {
                
                userimagerul=data.URL;
                


                   // Storing that Image

                         axios.post('http://localhost:5200/saveimage', {
                         lat: `${street_lat}`, 
                         lon: `${street_lon}`, 
                         ImageUrl: `${userimagerul}`,
                         pothole:`${street_pothole}`,
                         epole:`${street_epoles}`,

                         name: "Hamza",
                         date: new Date()
                       }).then(res => console.log(res)).catch(err => console.error(err));
    
                    console.log(`http://localhost:1000/saveimage/${street_lat}/${street_lon}/${userimagerul}`);
              }
    
          });
      });

      // Getting street ID which is near to that point

      streets.data.dbroad.rows.forEach(row => {
        street_id = row.osm_id;
      });
      // Updating the type value in selected street

      axios.get(`http://localhost:5200/updategid/${street_id}/${street_type}`);

       // Inserting date of update

      Date2=d.toDateString();

      axios.get(`http://localhost:5200/updatedate/${Date2}`);
      
    }



// Village Data Processing


async function Villageprocessing(){
 
  villagename = document.getElementById('vname').value;
  villagelat = document.getElementById('vlat').value;
  villagelon = document.getElementById('vlong').value;
  villagepop = document.getElementById('vpopu').value;
  villagemen = document.getElementById('vmen').value;
  villagewomen = document.getElementById('vwomen').value;
  villagevehcile = document.getElementById('vvehicle').value;
  villagedeath = document.getElementById('vdeath').value;
  villageaccident = document.getElementById('vaccident').value;
  villagegas = document.getElementById('vgas').value;
  villagebuilt = document.getElementById('vbuilt').value;
  villagepasture = document.getElementById('vpasture').value;
  villagebudget = document.getElementById('vbudget').value;




  villagebus = document.getElementById('vbus').value;
  villagecar = document.getElementById('vcar').value;
  villageecar = document.getElementById('vecar').value;
  villagemotobike = document.getElementById('vbike').value;
  villagerikshaw = document.getElementById('vrikshaw').value;

;

               // Storing that Image

                     axios.post('http://localhost:5200/villagedata', {
                     name:  `${villagename}`,
                     lat: `${villagelat}`, 
                     lon: `${villagelon}`, 
                     pop:  `${villagepop}`,
                     men:  `${villagemen}`,
                     women:  `${villagewomen}`,
                     vehicle:  `${villagevehcile}`,
                     death:  `${villagedeath}`,
                     accident:  `${villageaccident}`,
                     gas:  `${villagegas}`,
                     builtup:  `${villagebuilt}`,
                     pastures:  `${villagepasture}`,
                     budget:  `${villagebudget}`,

                     bus:  `${villagebus}`,
                     motorbike:  `${villagemotobike}`,
                     car:  `${villagecar}`,
                     ecar:  `${villageecar}`,
                     rikshaw:  `${villagerikshaw}`,

                   }).then(res => console.log(res)).catch(err => console.error(err));
                      // Inserting date of update

                    Date2=d.toDateString();

                    axios.get(`http://localhost:5200/updatedate/${Date2}`);
                   location.reload();


}




// Reloading function

    function reloadpage(){
      location.reload();
    }